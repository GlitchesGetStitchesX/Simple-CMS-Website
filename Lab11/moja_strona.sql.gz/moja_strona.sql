-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 17 Sty 2023, 14:49
-- Wersja serwera: 10.4.27-MariaDB
-- Wersja PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `moja_strona`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `category_list`
--

CREATE TABLE `category_list` (
  `id` int(255) NOT NULL,
  `matka` int(255) DEFAULT 0,
  `nazwa` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `category_list`
--

INSERT INTO `category_list` (`id`, `matka`, `nazwa`) VALUES
(1, 0, 'DVD'),
(2, 0, 'Blu-ray'),
(3, 1, 'Horror'),
(4, 2, 'Fantasy'),
(5, 0, 'VHS'),
(6, 5, 'Sci-Fi');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `page_list`
--

CREATE TABLE `page_list` (
  `id` int(11) NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `page_content` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `page_list`
--

INSERT INTO `page_list` (`id`, `page_title`, `page_content`, `status`) VALUES
(1, 'main', '<!DOCTYPE html>\r\n			<h1 class=\"film\">Newsy</h1>\r\n			<br>\r\n			<article>\r\n				<section>\r\n					<h2 class=\"film\">To już dziś!</h2>\r\n					<p class=\"text\">Dzisiaj, 27 marca 2022, odbędzie się 94. ceremonia wręczenia Oscarów! Wsród nominowanych są takie filmy jest \"Diuna\" czy \"West Side Story\". Pamiętajcie, że transmisja będzie trwać od 2:00 do 6:00 czasu polskiego. Tegorocznymi prowadzącymi są Regina Hall, Amy Schumer oraz Wanda Sykes. Z całą pewnością to wydarzenie będzie głównym tematem dyskusji przez cały miesiąc.</p>\r\n				</section>\r\n				<section>\r\n					<h2 class=\"film\">Nominacje ogłoszone</h2>\r\n					<p class=\"text\">Leslie Jordan oraz Tracee Ellis Ross ogłosili wszystkich nominowanych. Już wiemy, że w kategorii \"najlepszy film\" będą walczyć: \"CODA\", \"Belfast\", \"Nie patrz w górę\", \"Drive My Car\", \"Diuna\", \"King Richard. Zwycięska rodzina\", \"Licorice Pizza\", \"Zaułek koszmarów\", \"Psie pazury\" oraz \"West Side Story\". Jednocześnie Paul Thomas Anderson, Kenneth Branagh, Jane Campion, Ryusuke Hamaguchi oraz Steven Spielberg będą zmagać się o tytuł najlepszego reżysera.\r\n				</section>\r\n				<section>\r\n					<h2 class=\"film\">Nowa kategoria</h2>\r\n					<p class=\"text\">Dzisiaj dodaliśmy \"Ciekawostki\", przejdziesz do nich z menu. Mamy nadzieję, że każdy znajdzie coś zaskakującego. Miłego czytania!</p>\r\n				</section>\r\n			</article>', 1),
(2, 'nominacje', '<!DOCTYPE html>\r\n		<div>\r\n			<h1 class=\"film\">Nominacje 2021</h1>\r\n			<br>\r\n			<table class=\"table-style\">\r\n				<caption>Film</caption>\r\n			<thead>\r\n				<tr>\r\n					<th>Tytuł</th>\r\n					<th>Opis</th>\r\n					<th>Premiera</th>\r\n					<th>Reżyser</th>\r\n					<th>Plakat</th>\r\n				</tr>\r\n			</thead>\r\n			<tbody>\r\n				<tr>\r\n					<td><b>\"Nomadland\"</b><br><br><u>wygrana</u></td>\r\n					<td>Kobieta po sześćdziesiątce wybiera wędrowne życie współczesnego nomady, po tym jak w wyniku recesji straciła swój dobytek.</td>\r\n					<td>11 września 2020</td>\r\n					<td>Chloé Zhao</td>\r\n					<td><img id=\"animacjaPoster\" src=\"https://fwcdn.pl/fpo/71/68/837168/7950634.3.jpg\" class=\"posters\" /></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>\"Ojciec\"</b></td>\r\n					<td>Kobieta próbuje zaopiekować się ojcem wykazującym oznaki demencji, który mimo postępującej choroby pragnie pozostać samodzielny.</td>\r\n					<td>27 stycznia 2020</td>\r\n					<td>Florian Zeller</td>\r\n					<td><img id=\"animacjaPoster\" src=\"https://fwcdn.pl/fpo/54/69/835469/7959845.3.jpg\" class=\"posters\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>\"Judasz i Czarny Mesjasz\"</b></td>\r\n					<td>Historia Freda Hamptona, przewodniczącego Partii Czarnych Panter w Illinois i jego fatalnej zdrady dokonanej przez informatora FBI Williama O\'Neala.</td>\r\n					<td>1 lutego 2021</td>\r\n					<td>Shaka King</td>\r\n					<td><img id=\"animacjaPoster\" src=\"https://fwcdn.pl/fpo/80/91/858091/7958915.3.jpg\" class=\"posters\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>\"Obiecująca. Młoda. Kobieta.\"</b></td>\r\n					<td>Po tym jak tragiczne wydarzenia przekreśliły przyszłość Cassandry, młoda kobieta szuka zemsty na tych, którzy stają jej na drodze.</td>\r\n					<td>25 stycznia 2020</td>\r\n					<td>Emerald Fennell</td>\r\n					<td><img id=\"animacjaPoster\" src=\"https://fwcdn.pl/fpo/54/86/835486/7945202.3.jpg\" class=\"posters\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>\"Proces Siódemki z Chicago\"</b></td>\r\n					<td>Pokojowy protest przerodził się w brutalne starcie z policją, a jego organizatorzy stanęli przed sądem. Tak rozpoczął się jeden z najgłośniejszych procesów w historii.</td>\r\n					<td>25 września 2020</td>\r\n					<td>\"Aaron Sorkin\"</td>\r\n					<td><img id=\"animacjaPoster\" src=\"https://fwcdn.pl/fpo/12/41/451241/7931788.3.jpg\" class=\"posters\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>\"Sound of Metal\"</b></td>\r\n					<td>\"Opowieść o losach pary, która z dnia na dzień musi zmierzyć się z wyzwaniem bezpowrotnie zmieniającym ich życie.</td>\r\n					<td>6 sierpnia 2019</td>\r\n					<td>Darius Marder</td>\r\n					<td><img id=\"animacjaPoster\" src=\"https://fwcdn.pl/fpo/32/76/763276/7950897.3.jpg\" class=\"posters\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>\"Mank\"</b></td>\r\n					<td>Hollywood z lat 30. zostaje ocenione oczami zjadliwego krytyka społecznego i alkoholika – Hermana J. Mankiewicza, który ściga się, by skończyć scenariusz \"Obywatela Kane’a\" dla Orsona Wellesa.</td>\r\n					<td>13 listopada 2020</td>\r\n					<td>David Fincher</td>\r\n					<td><img id=\"animacjaPoster\" src=\"https://m.media-amazon.com/images/M/MV5BZTllMjI0ZGYtM2FmZC00ZmY4LTlkNTYtZThlOWQ1OGQyZTA3XkEyXkFqcGdeQXVyMDM2NDM2MQ@@._V1_.jpg\" class=\"posters\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>\"Minari\"</b></td>\r\n					<td>W pogoni za amerykańskim snem koreańska rodzina przenosi się do Arkansas i zakłada farmę.</td>\r\n					<td>26 stycznia 2020</td>\r\n					<td>Lee Isaac Chung</td>\r\n					<td><img id=\"animacjaPoster\" src=\"https://fwcdn.pl/fpo/83/44/848344/7963634.3.jpg\" class=\"posters\"/></td>\r\n				</tr>\r\n				</tbody>\r\n			</table>\r\n			</div>\r\n			<br>\r\n			<div>\r\n			<table class=\"table-style\">\r\n				<caption>Najlepszy aktor pierwszoplanowy</caption>\r\n				<thead>\r\n					<tr>\r\n						<th>Aktor</th>\r\n						<th>Film</th>\r\n						<th>Rola</th>\r\n						<th>Zdjęcie</th>\r\n					</tr>\r\n				</thead>\r\n			<tbody>\r\n				<tr>\r\n					<td><b>Anthony Hopkins</b><br><br><u>wygrana</u></td>\r\n					<td>\"Ojciec\"</td>\r\n					<td>Anthony</td>\r\n					<td><img id=\"animacjaPhoto\" src=\"https://fwcdn.pl/fph/54/69/835469/990513_1.2.jpg\" class=\"photos\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>Riz Ahmed</b></td>\r\n					<td>\"Sound of Metal\"</td>\r\n					<td>Ruben Stone</td>\r\n					<td><img id=\"animacjaPhoto\" src=\"https://fwcdn.pl/fph/32/76/763276/979486_1.2.jpg\" class=\"photos\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>Chadwick Boseman</b></td>\r\n					<td>\"Ma Rainey: Matka bluesa\"</td>\r\n					<td>Levee Green</td>\r\n					<td><img id=\"animacjaPhoto\" src=\"https://fwcdn.pl/fph/81/78/848178/956546_1.2.jpg\" class=\"photos\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>Gary Oldman</b></td>\r\n					<td>\"Mank\"</td>\r\n					<td>Herman J. Mankiewicz</td>\r\n					<td><img id=\"animacjaPhoto\" src=\"https://fwcdn.pl/fph/99/95/839995/968500_1.2.jpg\" class=\"photos\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>Steven Yeun</b></td>\r\n					<td>\"Minari\"</td>\r\n					<td>Jacob Yi</td>\r\n					<td><img id=\"animacjaPhoto\" src=\"https://fwcdn.pl/fph/83/44/848344/976334_1.2.jpg\" class=\"photos\"/></td>\r\n				</tr>\r\n			</tbody>\r\n			</table>\r\n			</div>\r\n			<br>\r\n			<div>\r\n				<table class=\"table-style\">\r\n					<caption>Najlepsza aktorka pierwszoplanowa</caption>\r\n					<thead>\r\n				<tr>\r\n					<th>Aktorka</th>\r\n					<th>Film</th>\r\n					<th>Rola</th>\r\n					<th>Zdjęcie</th>\r\n				</tr>\r\n					</thead>\r\n					<tbody>\r\n				<tr>\r\n					<td><b>Frances McDormand</b><br><br><u>wygrana</u></td>\r\n					<td>\"Nomadland\"</td>\r\n					<td>Fern</td>\r\n					<td><img id=\"animacjaPhoto\" src=\"https://fwcdn.pl/fph/71/68/837168/971241_1.2.jpg\" class=\"photos\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>Viola Davis</b></td>\r\n					<td>\"Ma Rainey: Matka bluesa\"</td>\r\n					<td>Ma Rainey</td>\r\n					<td><img id=\"animacjaPhoto\" src=\"https://fwcdn.pl/fph/81/78/848178/956548_1.2.jpg\" class=\"photos\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>Andra Day</b></td>\r\n					<td>\"Billie Holiday\"</td>\r\n					<td>Billie Holiday</td>\r\n					<td><img id=\"animacjaPhoto\" src=\"https://fwcdn.pl/fph/44/47/864447/996160_1.2.jpg\" class=\"photos\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>Vanessa Kirby</b></td>\r\n					<td>\"Cząstki kobiety\"</td>\r\n					<td>Martha Weiss</td>\r\n					<td><img id=\"animacjaPhoto\" src=\"https://fwcdn.pl/fph/45/17/854517/965019_1.2.jpg\" class=\"photos\"/></td>\r\n				</tr>\r\n				<tr>\r\n					<td><b>Carey Mulligan</b></td>\r\n					<td>\"Obiecująca. Młoda. Kobieta.\"</td>\r\n					<td>Cassandra Thomas</td>\r\n					<td><img id=\"animacjaPhoto\" src=\"https://fwcdn.pl/fph/54/86/835486/987644_1.2.jpg\" class=\"photos\"/></td>\r\n				</tr>\r\n				</tbody>\r\n				<script src=\"/js/animation.js\"></script>\r\n			</table>', 1),
(3, 'rekordy', '<!DOCTYPE html>\r\n			<h1 class=\"film\">Rekordy filmowe</h1>\r\n			<h2 class=\"film\">Dotychczas trzem filmom udało się zdobyć najwyższą dotąd liczbę jedenastu oscarowych statuetek:</h2>\r\n			<ul class=\"text\">\r\n				<li>Ben-Hur (1959)</li>\r\n				<li>Titanic (1997)</li>\r\n				<li>Władca Pierścieni: Powrót króla (2003)</li>\r\n			</ul>\r\n			<h2 class=\"film\">Trzem filmom udało się zdobyć pięć najważniejszych Oscarów (film, reżyseria, scenariusz, główna rola męska i kobieca):</h2>\r\n			<ul class=\"text\">\r\n				<li>Ich noce (1934)</li>\r\n				<li>Lot nad kukułczym gniazdem (1975)</li>\r\n				<li>Milczenie owiec (1991)</li>\r\n			</ul>\r\n			<h2 class=\"film\">Najwięcej, bo 14 nominacji, do nagrody otrzymały filmy:</h2>\r\n			<ul class=\"text\">\r\n				<li>Titanic (1997)</li>\r\n				<li>Wszystko o Ewie (1950)</li>\r\n				<li>La La Land (2016)</li>\r\n			</ul>\r\n			<h2 class=\"film\">Osoby z największą liczbą nominacji, które nigdy nie zdobyły Oscara:</h2>\r\n			<ul class=\"text\">\r\n				<li>Roland Anderson (15 - scenografia)</li>\r\n				<li>Alex North (15 - muzyka i piosenka, oscar honorowy)</li>\r\n				<li>Thomas Newman (14 - muzyka i piosenka)</li>\r\n				<li>George J. Folsey (13 - zdjęcia)</li>\r\n				<li>Federico Fellini (12 - reżyseria i scenariusz, oscar honorowy)</li>\r\n			</ul>', 1),
(4, 'ciekawostki', '<!DOCTYPE html>\r\n			<h1 class=\"film\">Ciekawostki</h1>\r\n      <button class=\"accordion\">Pierwszy Oscar</button>\r\n      <div class=\"panel\">\r\n        <p>Został wręczony <b>16 maja w 1929 roku.</b></p>\r\n      </div>\r\n\r\n      <button class=\"accordion\">Projektant statuetki</button>\r\n      <div class=\"panel\">\r\n        <p>Dobrze znana nam statuetka została zaprojektowana przez <b>Cedrica Gibbonsa</b> w 1928.</b></p>\r\n      </div>\r\n\r\n      <button class=\"accordion\">Pierwsza transmisja z Oscarów</button>\r\n      <div class=\"panel\">\r\n        <p>Odbyła się <b>1953.</b></p>\r\n      </div>\r\n\r\n      <button class=\"accordion\">Pierwsza transmisja z Oscarów w kolorze</button>\r\n      <div class=\"panel\">\r\n        <p>Mogliśmy zobaczyć w <b>1966</b> roku.</b></p>\r\n      </div>\r\n\r\n      <button class=\"accordion\">Pierwszy film w kolorze, który wygrał statuetkę</button>\r\n      <div class=\"panel\">\r\n        <p>Był to film pod tytułem <b>\"Przeminęło z wiatrem\"</b> w 1940.</p>\r\n      </div>\r\n\r\n      <button class=\"accordion\">Najkosztowniejszy zwycięzca</button>\r\n      <div class=\"panel\">\r\n        <p>Najdroższy film, który wygrał, to <b>\"Avatar\"</b>.</p>\r\n      </div>\r\n\r\n      <button class=\"accordion\">Najczęściej nominowana osoba</button>\r\n      <div class=\"panel\">\r\n        <p>Rekord ten należy do <b>Meril Streep</b>, została nominowana 21 razy.</p>\r\n      </div>\r\n\r\n      <button class=\"accordion\">Gdzie odbywa się coroczna gala</button>\r\n      <div class=\"panel\">\r\n        <p>W <b>The Dolby Theatre</b> w Hollywood.</b></p>\r\n      </div>', 1),
(5, 'zasady', '<!DOCTYPE html>\r\n			<div class=\"wrapingimage\">\r\n				<img class=\"wrap\" src=\"https://upload.wikimedia.org/wikipedia/en/7/7f/Academy_Award_trophy.png\">\r\n			</div>\r\n			<h1 class=\"film\">Zasady</h1>\r\n			<br>\r\n			<p class=\"text\">Aby dostać nominację oraz wygrać dana osoba lub film musi przebyć długą drogę, którą wytłumaczymy:</p>\r\n			<h2 class=\"film\">Zgłaszanie filmów oraz osób do nominacji</h2>\r\n			<p class=\"text\">By film mógł w ogóle się ubiegać o nominację musi spełnić kilka podstawowych warunków:</p>\r\n			<ul class=\"text\">\r\n				<li>musi trwać co najmniej 40 minut</li>\r\n				<li>musi mieć publiczną premierę w kinie w danym roku kalendarzowym</li>\r\n				<li>musi być wyświetlany w standardzie filmu 35mm, 70mm lub 24-klatkowym albo 48-klatkowym cyfrowym formacie</li>\r\n				<li>musi być wyświetlany w kinie na terenie hrabstwa Los Angeles przez minimum siedem dni z rzędu, a wstęp na seans musi być płatny (i przynajmniej jeden musi odbywać się między godzinami 18, a 22)</li>\r\n				<li>mieć kampanię reklamową (w dowolnej, przyjętej za standardową w praktyce, formie) na terenie hrabstwa Los Angeles</li>\r\n			</ul>\r\n			<p class=\"text\" >Jeśli dana produkcja spełnia wszystkie powyższe warunki to jej producent lub dystrybutor może do końca listopada wypełnić stosowny formularz i wysłać go do Akademii zgłaszając jego aspiracje do zdobycia nagród. Jeśli film ma mieć swoją premierę w grudniu, do dnia 15 grudnia danego roku dodatkowo nadesłana musi być lista planowanych seansów do końca tego roku.</p>\r\n			<h2 class=\"film\">Głosowanie na filmy oraz osoby, które otrzymają nominację</h2>\r\n			<p class=\"text\">Kto może brać udział w głosowaniu? Wszyscy aktywni członkowie Amerykańskiej Akademii Sztuki i Wiedzy Filmowej, których w chwili obecnej jest ponad 6000.</p>\r\n			<h2 class=\"film\">Jak przeliczane są głosy?</h2>\r\n			<p class=\"text\">Najpierw specjaliści liczą sumę wszystkich wskazanych osób na kartach do głosowania. Powiedzmy, że w kategorii aktorskiej głosuje 3000 osób, które wskazują na różnych miejscach swojej listy łącznie 30 faworytów do nagrody. Przelicza się wówczas 3000 i dzieli przez 6 (liczba pięciu możliwych nominowanych plus jeden) i mamy liczbę 500. To tak zwana „Magiczna Liczba” Jeśli spośród 30 osób wskazanych na dowolnym miejscu w kartach członków Akademii znajdą się osoby wskazane 500 razy – wówczas łapią się do węższego grona wskazanych osób.Następnie mamy ponowne liczenie, tym razem liczy się liczba zgłoszeń na pierwszym miejscu na kartach głosujących. Bo pamiętacie, że każdy może wskazać w danej kategorii kilku faworytów, więc Magiczną Liczbę na wszystkich kartach może otrzymać łącznie więcej osób niż można nominować. I tutaj wreszcie liczy się waga głosu – wskazanie na pierwszym miejscu na liście.</p>\r\n			<h2 class=\"film\">Głosowanie na filmy oraz osoby, które zdobędą nagrodę</h2>\r\n			<p class=\"text\">Po ogłoszeniu nominacji (w każdym roku Akademia ustala szczegółowy harmonogram dla konkretnego roku, więc jest to data ruchoma) znowu rusza wielka machina logistyczna i rozsyłane są karty do głosowania do wszystkich członków Akademii.System głosowania się już nieco zmienia. W przeciwieństwie do głosowania na nominacje nie ma już możliwości wskazywania kilku faworytów – każdy może głosować wyłącznie na jedną nominowaną osobę lub produkcję. I wygrywa oczywiście nominacja z największą liczbą głosów. Bez ważenia głosów, Magicznych Liczb i innych komplikacji.Jednak w przeciwieństwie do etapu nominowania, tutaj każdy głosuje na każdą kategorię.</p>', 1),
(6, 'trailery', '<!DOCTYPE html>\r\n			<h1 class=\"film\">Trailery</h1>\r\n			<br>\r\n			<article>\r\n				<div>\r\n				<h2 class=\"film\">Nomadland</h2>\r\n				<iframe class=\"trailer\" width=\"893\" height=\"502\" src=\"https://www.youtube.com/embed/6sxCFZ8_d84\" title=\"NOMADLAND | Official Trailer | Searchlight Pictures\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\r\n				</div>\r\n				<div>\r\n				<h2 class=\"film\">Ojciec</h2>\r\n				<iframe class=\"trailer\" width=\"893\" height=\"374\" src=\"https://www.youtube.com/embed/4TZb7YfK-JI\" title=\"THE FATHER | Official Trailer (2020)\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\r\n				</div>\r\n				<div>\r\n				<h2 class=\"film\">Judasz i Czarny Mesjasz</h2>\r\n				<iframe class=\"trailer\" width=\"893\" height=\"502\" src=\"https://www.youtube.com/embed/sSjtGqRXQ9Y\" title=\"JUDAS AND THE BLACK MESSIAH - Official Trailer\" frameborder=\"0\" allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen></iframe>\r\n				</div>\r\n			</article>', 1),
(7, 'kontakt', '<!DOCTYPE html>\r\n			<h1 class=\"film\">Kontakt</h1>\r\n			<br>\r\n			<div class=\"email-container\">\r\n			<form>\r\n				<input type=\"email\" id=\"fname\" maxlength=\"64\" placeholder=\"jkowalski@email.pl\">\r\n\r\n				<textarea id=\"subject\" name=\"subject\" placeholder=\"Moja wiadomość\" style=\"height:200px\"></textarea>\r\n\r\n				<input type=\"submit\" value=\"Wyślij\"/>\r\n			</form>\r\n			</div>', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `product_list`
--

CREATE TABLE `product_list` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `create_date` date NOT NULL,
  `modify_date` date NOT NULL,
  `netto_price` float NOT NULL,
  `vat` int(10) NOT NULL,
  `stock` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `size` varchar(5) NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `user_list`
--

CREATE TABLE `user_list` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Zrzut danych tabeli `user_list`
--

INSERT INTO `user_list` (`user_id`, `user_name`, `user_password`) VALUES
(1, 'admin', '5f4dcc3b5aa765d61d8327deb882cf99');

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `category_list`
--
ALTER TABLE `category_list`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `page_list`
--
ALTER TABLE `page_list`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `product_list`
--
ALTER TABLE `product_list`
  ADD PRIMARY KEY (`id`);

--
-- Indeksy dla tabeli `user_list`
--
ALTER TABLE `user_list`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `category_list`
--
ALTER TABLE `category_list`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT dla tabeli `page_list`
--
ALTER TABLE `page_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT dla tabeli `product_list`
--
ALTER TABLE `product_list`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT dla tabeli `user_list`
--
ALTER TABLE `user_list`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
